﻿namespace Nop.Core.Domain.Messages
{
    /// <summary>
    /// Represents the period of message delay
    /// </summary>
    public enum MessageDelayPeriod
    {
        /// <summary>
        /// Hours
        /// </summary>
        Hours = 0,

        /// <summary>
        /// Days
        /// </summary>
        Days = 1
    }
}
